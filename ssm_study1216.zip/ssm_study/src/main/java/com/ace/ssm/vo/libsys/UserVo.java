package com.ace.ssm.vo.libsys;

import com.ace.ssm.domain.libsys.User;

public class UserVo extends User{
	
	

}
