package com.ace.ssm.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TestController {

}
